<?php
if($_REQUEST['action']=='send'){ //ossia solo se la variabile action è impostata ed uguale a send

		$idsito          =  IDSITO;                              //(ID del sito,   richiedere a Network Service: arcello@network-service.it)
		$urlback         =  'https//www.nomedelsito.it/grazie/'; //(Indirizzo del vostro sito con la pagina di atterraggio dopo l'invio del form)
		$id_lingua       =  1;                                   //(Italiano = 1, Inglese    =2,  Francese = 3, Tedesco =   4)
		$language        =  'it';                    			 //(Italiano  =  'it',  Inglese = 'en', Francese = 'fr',  Tedesco = 'de')

		$data_A          =  str_replace("/","-",$_REQUEST['data_arrivo']);
		$data_A_tmp      =  explode("-",$data_A);
		$data_arrivo     =  $data_A_tmp[2].'-'.$data_A_tmp[1].'-'.$data_A_tmp[0];

		$data_P          =  str_replace("/","-",$_REQUEST['data_partenza']);
		$data_P_tmp      =  explode("-",$data_P);
		$data_partenza   =  $data_P_tmp[2].'-'.$data_P_tmp[1].'-'.$data_P_tmp[0];
		
            $campi = array(
                            'nome'          => $_REQUEST['nome'],       //obbligatorio
                            'cognome'       => $_REQUEST['cognome'],    //obbligatorio
                            'email'         => $_REQUEST['email'],      //obbligatorio
                            'action'        => 'send',                  //obbligatorio
                            'language'      => $_REQUEST['language'],   //obbligatorio
                            'id_lingua'     => $_REQUEST['id_lingua'],  //obbligatorio
                            'idsito'        => $idsito,                 //obbligatorio
                            'urlback'       => $urlback,                //obbligatorio
                            'telefono'      => $_REQUEST['telefono'],
                            'data_arrivo'   => $_REQUEST['data_arrivo'],    // dd-mm-yyyy  - obbligatorio
                            'data_partenza' => $_REQUEST['data_partenza'],  // dd-mm-yyyy  - obbligatorio
                            'DataArrivo'    => $_REQUEST['DataArrivo'],     // dd-mm-yyyy date alternative - opzionale
                            'DataPartenza'  => $_REQUEST['DataPartenza'],   // dd-mm-yyyy date alternative - opzionale
                            'adulti'        => $_REQUEST['adulti'],         //obbligatorio
                            'bambini'       => $_REQUEST['bambini'],        //obbligatorio
                            'TipoVacanza'   => $_REQUEST['TipoVacanza'],    //  (Family, Business, Fiera, Benessere, Divertimento, Sport)

                            'TipoSoggiorno[]'=> $_REQUEST['TipoSoggiorno'][$i], //altamente consigliato ma non obbligatorio
                            'NumeroCamere[]' => $_REQUEST['NumeroCamere'][$i],
                            'TipoCamere[]'   => $_REQUEST['TipoCamere'][$i],
                            'NumAdulti[]'    => $_REQUEST['NumAdulti'][$i],     //altamente consigliato ma non obbligatorio
                            'NumBambini[]'   => $_REQUEST['NumBambini'][$i],    //altamente consigliato ma non obbligatorio
                            'EtaB[]'         => $_REQUEST['EtaB'][$i],          //altamente consigliato ma non obbligatorio

                            'hotel'         => $_REQUEST['hotel'],//(opzionale: solo se si tratta di una multi struttura)

                            'messaggio'     => $_REQUEST['messaggio'],
                            'codice_sconto' => $_REQUEST['codice_sconto'],
                            'marketing'     => $_REQUEST['marketing'],
                            'profilazione'  => $_REQUEST['profilazione'],
                            'privacy'       => $_REQUEST['privacy'],         //obbligatorio
                            'tracking'      => urlencode($_SERVER['REQUEST_URI']), //obbligatorio
                            'CLIENT_ID'     => $_REQUEST['CLIENT_ID']  //obbligatorio
                        );

                      $dati = '';
                      foreach ($campi as $k => $v) {
                        $dati .= $k . '=' . urlencode($v) . '&';
                      }
                      rtrim($dati, '&');

                      $user    = '........'; //(richiedere a Network Service : marcello@network-service.it)
                      $pass    = '........'; //(richiedere a Network Service : marcello@network-service.it)
                      $ch = curl_init();
                      curl_setopt($ch, CURLOPT_URL, 'https://www.quotocrm.it/ApiFormQuoto/api_form_2_ads.php');
                      curl_setopt($ch, CURLOPT_USERPWD, $user.':'.$pass);
                      curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
                      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 0);
                      curl_setopt($ch, CURLOPT_POST, true);
                      curl_setopt($ch, CURLOPT_POSTFIELDS, $dati);
                      curl_exec($ch);
                      curl_close($ch);

}

					/**
					* ! la riga delle camere dinamica (ANCHE SE FOSSE UNA SOLA)
					* ! va aggiunta alla variabile $_request['messaggio']
					* ! ossia nel box dedicato alle note del form va inserito il riepilogo del
					* ! Trattamento -> Numero camera -> Tipo Camera ->Num Adulti -> Num Bambini -> età bambini
					* ! naturalmente non essendo obbligatori il Numero camera ed  Tipo Camera, possono essere tralasciati.
					*/
		?>		
        <!--
/**
* INSERIRE OBBLIGATORIAMENTE QUESTO SCRIPT NELLA COSTRUZIONE DEL FORM dentro il tag <form></form>
* La vostra pagina di atterraggio deve avere la libreria JQuery
* (il mancato inserimento pregiudicherebbe il tracciamento delle campagne ADS)
*/
-->
		<script>
		function leggiCookie(nomeCookie) {
			if (document.cookie.length > 0) {
					var inizio = document.cookie.indexOf(nomeCookie + "=");
					if (inizio != -1) {
						inizio = inizio + nomeCookie.length + 1;
						var fine = document.cookie.indexOf(";", inizio);
						if (fine == -1) fine = document.cookie.length;
						return unescape(document.cookie.substring(inizio, fine));
					} else {
						return "";
					}
				}
				return "";
			}
			$(document).ready(function(){
				setTimeout(function(){
					var CLIENT_ID_ = leggiCookie("_ga");
					var CLIENT_ID_tmp =  CLIENT_ID_.split(".");
					var CLIENT_ID = CLIENT_ID_tmp[2]+"."+CLIENT_ID_tmp[3];
					$("#load_client_id").html('<input type="hidden" name="CLIENT_ID" value="'+CLIENT_ID+'" />');
				}, 3000);
			});

		</script>
		<div id="load_client_id"></div>


###################################################################################################################################################	
/**
* INSERIRE OBBLIGATORIAMENTE QUESTO SCRIPT NELLA PAGINA dentro il tag <head></head> DI RITORNO DAL INVIO DEL VOSTRO FORM
* La vostra pagina di atterraggio deve avere la libreria JQuery 
* (il mancato inserimento pregiudicherebbe il tracciamento delle campagne ADS)
*/		
<script>
	window.dataLayer = window.dataLayer || []; 
	dataLayer.push({'event': 'Init', 'NumeroPrenotazione': '<?=$_REQUEST['NumeroPrenotazione']?>#<?=$_REQUEST['idsito']?>'});
</script>
