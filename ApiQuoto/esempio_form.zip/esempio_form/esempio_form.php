<?php
    $TagManager = 'GTM-XXXXXXXX';
    $language   = 'it';
    $id_lingua  = '1';
    $idsito     = 'XXXX';
    $urlback    = 'PAGINA DI ATTERRAGGIO, CHE POTREBBE ESSERE ANCHE SU SE STESSA CON  IF IN FONDO';
?>
!DOCTYPE html>
<html lang="it">
	<head>
		<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
        <title>Form di test</title>
        <meta name="description" content="Form di test"/>
        <meta name="author" content="">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js" integrity="sha256-0YPKAwZP7Mp3ALMRVB2i8GXeEndvCq3eSl/WsAl1Ryk=" crossorigin="anonymous"></script>
        
        <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
		<script type="text/javascript" src="https://www.google.com/recaptcha/api.js<?=($language=='it'?'':'?hl='.$language)?>" async defer></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js" integrity="sha512-T/tUfKSV1bihCnd+MxKD0Hm1uBBroVYBOYSk1knyvQ9VyZJpc/ALb4P0r6ubwVPSGB2GvjeoMAJJImBG12TiaQ==" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css" integrity="sha512-mSYUmp1HYZDFaVKK//63EcZq4iFWFjxSL+Z3T/aCt4IO9Cejm03q3NKKYN6pFQzY0SBOr8h+eCIAZHPXcpZaNw==" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/locales/bootstrap-datepicker.it.min.js" integrity="sha512-0MThRHKyDbl5nH553hVBJMo2Ma7c2c5jU2bENv92XM2SVQEcQ7vepANdKiU7DLiYH9RsqESRdDpCRVkIRGtKGQ==" crossorigin="anonymous"></script>
     
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js" integrity="sha512-UdIMMlVx0HEynClOIFSyOrPggomfhBKJE28LKl8yR3ghkgugPnG6iLfRfHwushZl1MOPSY6TsuBDGPK2X4zYKg==" crossorigin="anonymous"></script>
        <?php include('functions.js.php')?>
	
	</head>
<body>
<?php if(!$_REQUEST['res']){?>
<form class="form" name="form_richiesta" id="form_richiesta" action="<?=$_SERVER['REQUEST_URI']?>" method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-lg-12  col-md-12 col-sm-12 col-xs-12">
                        <input type="hidden" name="res" value="sent" />
                        <input type="hidden" name="language" value="<?=$language?>" />
                        <input type="hidden" name="id_lingua" value="<?=$id_lingua?>" />
                        <input type="hidden" name="idsito" value="<?=$idsito?>" />
                        <input type="hidden" name="urlback" value="<?=$urlback?>"/>
                        <input type="hidden" name="adulti" id="adulti<?=$idsito?>" value="" />
                        <input type="hidden" name="bambini" id="bambini<?=$idsito?>" value="" />
                        <script>
                            function leggiCookie(nomeCookie) {
                                if (document.cookie.length > 0) {
                                        var inizio = document.cookie.indexOf(nomeCookie + "=");
                                        if (inizio != -1) {
                                            inizio = inizio + nomeCookie.length + 1;
                                            var fine = document.cookie.indexOf(";", inizio);
                                            if (fine == -1) fine = document.cookie.length;
                                            return unescape(document.cookie.substring(inizio, fine));
                                        } else {
                                            return "";
                                        }
                                    }
                                    return "";
                                }
                                $(document).ready(function(){
                                    setTimeout(function(){
                                        var CLIENT_ID_ = leggiCookie("_ga");
                                        var CLIENT_ID_tmp =  CLIENT_ID_.split(".");
                                        var CLIENT_ID = CLIENT_ID_tmp[2]+"."+CLIENT_ID_tmp[3];
                                        $("#load_client_id").html('<input type="hidden" name="CLIENT_ID" value="'+CLIENT_ID+'" />');
                                    }, 3000);
                                });

                            </script>
                        <div id="load_client_id"></div>
                    </div>
                </div>
                <br />
        <div class="card">
        <div class="card-header"><span class="titolo-card">Dati personali</span></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-12  col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                            <div class="col-lg-6  col-md-6 col-sm-6 col-xs-12">
                                                            <input type="text" name="nome" id="nome" placeholder="Nome *" autocomplete="off" class="form-control " />
                            </div>
                            <div class="col-lg-6  col-md-6 col-sm-6 col-xs-12">
                                                            <input type="text" name="cognome" id="cognome" placeholder="Cognome *" autocomplete="off" class="form-control " />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12  col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                            <div class="col-lg-6  col-md-6 col-sm-6 col-xs-12">
                                                            <input type="email" name="email" id="email" placeholder="Email *" autocomplete="off" class="form-control " />
                                                            </div>
                            <div class="col-lg-6  col-md-6 col-sm-6 col-xs-12">
                                                            <input type="text" name="telefono" id="telefono" placeholder="Telefono" autocomplete="off" class="form-control " />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br />
        <div class="card">
        <div class="card-header"><span class="titolo-card">Date del soggiorno</span></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-12  col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                            <div class="col-lg-6  col-md-6 col-sm-6 col-xs-12">
                                                                <input type="text" onKeyDown="return false" name="data_arrivo" id="data_arrivo_quoto"  placeholder="Data Arrivo *" autocomplete="off" class="form-control " />
                            </div>
                            <div class="col-lg-6  col-md-6 col-sm-6 col-xs-12">
                                                                <input type="text" onKeyDown="return false" name="data_partenza" id="data_partenza_quoto"  placeholder="Data Partenza *" autocomplete="off" class="form-control " />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <small><a href="javascript:;" id="plus_date"><i class="fa fa-fw  fa-plus"></i> aggiungi date alternative</a></small>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12  col-md-12 col-sm-12 col-xs-12">
                        <div  id="date_alternative" style="display:none">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                                <input onKeyDown="return false" id="DataArrivo_1_quoto" name="DataArrivo" type="text" placeholder="Arrivo alternativo " autocomplete="off" class="form-control " />
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                                <input onKeyDown="return false" id="DataPartenza_1_quoto" name="DataPartenza" type="text" placeholder="Partenza alternativa" autocomplete="off" class="form-control " />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br />
        <div class="card">
        <div class="card-header"><span class="titolo-card">Dati del soggiorno</span></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-12  col-md-12 col-sm-12 col-xs-12 padding-right-22">
                                            <br />
                        <small id="legend">Scegli il tipo o il motivo della tua vacanza</small>
                        <div style="clear:both"></div>
                        <div class="row">
                            <div class="col-lg-4  col-md-4 col-sm-12 col-xs-12">
                                                                <select name="TipoVacanza" id="TipoVacanza" class="form-control padding6-12 ">
                                    <option value="" selected="selected">Tipologia vacanza</option>
                                    <option value="Benessere">Benessere</option><option value="Bike">Bike</option><option value="Business">Business</option><option value="Divertimento">Divertimento</option><option value="Family">Family</option><option value="Gruppo famiglia">Gruppo famiglia</option><option value="Romantico">Romantico</option><option value="Sport">Sport</option>                                </select>
                            </div>
                        </div>
                                            <br />
                        <small id="legend">Scegli e/o aggiungi il trattamento e distribuisci i partecipanti</small>
                        <div style="clear:both"></div>
                        <div class="row">

                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                                                                    <select name="TipoSoggiorno[]" id="TipoSoggiorno_1_1" class="form-control padding6-12 ">
                                                <option value="" selected="selected">Trattamento *</option>
                                                <option value="Bed & Breakfast">Bed & Breakfast</option><option value="Mezza Pensione">Mezza Pensione</option><option value="Pensione Completa">Pensione Completa</option><option value="Solo Pernotto">Solo Pernotto</option>                                            </select>

                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                                                                <select name="NumeroCamere[]" id="NumeroCamere_1_1" class="form-control padding6-12 ">
                                            <option value="" selected="selected">Nr.Camere *</option>
                                            <option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option>                                        </select>

                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                                                    <select name="TipoCamere[]" id="TipoCamere_1_1" class="form-control padding6-12 ">
                                        <option value="" selected="selected">Tipologia camera *</option>
                                           <option value="Camera Doppia">Camera Doppia</option><option value="Camera Matrimoniale">Camera Matrimoniale</option><option value="Camera Singola">Camera Singola</option><option value="Camera Suite">Camera Suite</option>                                    </select>

                                </div>

                        </div>
                        <div class="row">

                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                                                                <select name="NumAdulti[]" id="NumeroAdulti_1_1" class="form-control padding6-12 " onchange="calcola_totale_adulti();">
                                            <option value="" selected="selected">Nr.Adulti *</option>
                                            <option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option><option value="11">11</option><option value="12">12</option><option value="13">13</option><option value="14">14</option><option value="15">15</option><option value="16">16</option><option value="17">17</option><option value="18">18</option><option value="19">19</option><option value="20">20</option>                                        </select>

                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                                                                <select name="NumBambini[]" id="NumeroBambini_1_1" class="NumeroBambini_1_1 form-control padding6-12 "  onchange="eta_bimbi('1_1');calcola_totale_bambini();equalizza_change_bambini();">
                                            <option value="" selected="selected">Nr.Bambini</option>
                                            <option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option>                                        </select>

                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                            <input type="text"  name="EtaB[]" placeholder="Età: 1,3 mesi,<1" class="form-control " />
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-left">
                                    <small>
                                        <a href="javascript:;" id="add"  onclick="room_fields(1,'righe_room');checkDimension();">
                                            <i class="fa fa-fw  fa-plus"></i> aggiungi camera                                        </a>
                                    </small>
                                </div>
                        </div>
                    <div id="righe_room"></div>
                </div>
            </div>
        </div>
    </div>
    <br />
    <div class="card">
    <div class="card-header"><span class="titolo-card">Qualcosa da comunicarci</span></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <textarea name="messaggio" id="messaggio" rows="4" placeholder="Messaggio" class="form-control "></textarea>
                            <br />
                            <div class="g-recaptcha" data-sitekey="SITEKEY"></div>
                            <br />
                            <input type="checkbox" id="marketing" name="marketing" value="on"><span class="txtprivacy"> Do il consenso per ricevere materiale marketing</span><br>
                            <span id="view_profilazione" style="display:none"><input name="profilazione" id="profilazione" type="checkbox"  value="on" /><span class="txtprivacy"> Voglio ricevere le offerte in linea con le preferenze che ho indicato</span><br></span>
                            <input name="privacy" id="privacy" type="checkbox"  value="checkbox" /><span class="txtprivacy"> Ho preso visione dell'informativa privacy - </span>
                                <a href="javascript:;" id="link_privacy" class="txtprivacy" title="Privacy Policy">Visualizza Informativa</a>
                            <div style="clear:both"></div>
                            <div  id="box_privacy" style="display:none;overflow-y: auto">
                                    <small>Inserire informativa </small>
                            </div>   
                            <br />
                            <div id="view_send_form_loading"></div>
                            <button class="SW-submit" type="submit" id="pulsante-invio">Invia Richiesta</button>
                            <br />
                            <span class="txtprivacy">* campo obbligatorio</span>
                    </div>
                </div>
            </div>
        </div>
        <br />
    </form>
    <?}else{?>
		<?php
            $content = '  	<script>
                                window.dataLayer = window.dataLayer || []; 
                                dataLayer.push({\'event\': \'Init\', \'NumeroPrenotazione\': \''.$_REQUEST['NumeroPrenotazione'].'#'.$_REQUEST['idsito'].'\'});
							</script>'."\r\n";
			echo $content;
		?>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                Invio richiesta effettuato con successo!
            </div>
        </div>
	<?}?>
    </body>
</html>