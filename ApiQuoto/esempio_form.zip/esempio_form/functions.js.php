<script>
    var linea = 1;

    function room_fields(n_proposta,id) {

        linea++;
        var objTo = document.getElementById(id)
        var divtest = document.createElement("div");
        divtest.setAttribute("class", "removeclass" + linea);
        var rdiv = 'removeclass' + linea;

        divtest.innerHTML = '<div style="clearfix"></div>' 
                            +'<div class="row">'
                            +'<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12"><?php if($view_icon == 1){?><div class="icon-group righeSogg"><i class="fa fa-fw  fa-suitcase onselect"></i></div><?}?> <select name="TipoSoggiorno[]" id="TipoSoggiorno_' + n_proposta + '" class="form-control padding6-12"><option value="" selected="selected">Trattamento *</option><option value="Bed & Breakfast">Bed & Breakfast</option><option value="Mezza Pensione">Mezza Pensione</option><option value="Pensione Completa">Pensione Completa</option><option value="Solo Pernotto">Solo Pernotto</option></select></div>'
                            +'<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12"><?php if($view_icon == 1){?><div class="icon-group righeSogg"><i class="fa fa-fw  fa-list onselect"></i></div><?}?> <select name="NumeroCamere[]" id="NumeroCamere_' + n_proposta + '" class="form-control padding6-12"><option value="" selected="selected">Nr.Camere *</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option></select></div>'
                            +'<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12"><?php if($view_icon == 1){?><div class="icon-group righeSogg"><i class="fa fa-fw  fa-bed onselect"></i></div><?}?> <select name="TipoCamere[]" id="TipoCamere_' + n_proposta + '" class="form-control  padding6-12"><option value="" selected="selected">Tipologia camera *</option><option value="Camera Doppia">Camera Doppia</option><option value="Camera Matrimoniale">Camera Matrimoniale</option><option value="Camera Singola">Camera Singola</option><option value="Camera Suite">Camera Suite</option></select></div>'
                            +'</div>'
                            +'<div class="row">'
                            +'<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12"><?php if($view_icon == 1){?><div class="icon-group righeSogg"><i class="fa fa-fw  fa-male onselect"></i></div><?}?> <select name="NumAdulti[]" id="NumeroAdulti_' + n_proposta + '" class="form-control padding6-12" onchange="calcola_totale_adulti();"><option value="" selected="selected">Nr.Adulti *</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option><option value="11">11</option><option value="12">12</option><option value="13">13</option><option value="14">14</option><option value="15">15</option><option value="16">16</option><option value="17">17</option><option value="18">18</option><option value="19">19</option><option value="20">20</option></select></div>'
                            +'<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12"><?php if($view_icon == 1){?><div class="icon-group righeSogg"><i class="fa fa-fw  fa-child onselect"></i></div><?}?> <select name="NumBambini[]"  class="NumeroBambini_' + n_proposta + '_' + linea + ' form-control padding6-12"  onchange="eta_bimbi(\'' + n_proposta + '_' + linea + '\');calcola_totale_bambini();equalizza_change_bambini();"><option value="" selected="selected">Nr.Bambini</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option> </select></div>'                        
                            +'<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12"><input type="text"  name="EtaB[]" placeholder="Età: 1,3 mesi,< 1" class="form-control" autocomplete="off"></div>'
                            +'<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-left"><small><a id="re" href="javascript:;"  onclick="remove_room_fields(' + linea + ');"><i class="fa fa-fw  fa-minus"></i> rimuovi camera</a></small></div>'
                            +'</div>';

        objTo.appendChild(divtest);

            EQR();

    }

    function remove_room_fields(rid) {
        $('.removeclass' + rid).remove();
        
            EQR();
        
    }

$(function() {
    $.datepicker.setDefaults({
        showOn: 'both',
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd-mm-yy',
        minDate: "+1d",
        numberOfMonths: 1
    });

    var cal_start = "#data_arrivo_quoto";
    var cal_end = "#data_partenza_quoto";
    var dates = $(cal_start + "," + cal_end).datepicker({
        defaultDate: "+7",
        onSelect: function(selectedDate) {
        if (this.id.indexOf('data_arrivo') > -1) {
            var date = $(cal_start).datepicker('getDate', '+1d');
            date.setDate(date.getDate() + 1);
            $(cal_end).datepicker('setDate', date);
            $(cal_end).datepicker("option", "minDate", date);
        }
        }
    });

    var cal_start2 = "#DataArrivo_1_quoto";
    var cal_end2 = "#DataPartenza_1_quoto";
    var dates2 = $(cal_start2 + "," + cal_end2).datepicker({
        defaultDate: "+7",
        onSelect: function(selectedDate) {
            if (this.id.indexOf('DataArrivo') > -1) {
                var date2 = $(cal_start2).datepicker('getDate', '+1d');
                date2.setDate(date2.getDate() + 1);
                $(cal_end2).datepicker('setDate', date2);
                $(cal_end2).datepicker("option", "minDate", date2);
            }
        }
    });

});
$(document).ready(function() {

    /**
    * ! RITARDO APERTURA FORM
    * */
    setTimeout(function(){
        $("#loader-content-quoto").fadeOut(200);
        $("#form-show").fadeIn();

            setTimeout(function(){
                EQR();
            }, 2000);

    }, 2000);

    $("#form_richiesta").validate({
        rules: {
            nome: "required",
            cognome: "required",
            email: {
                required: true,
                email: true
            },
            privacy: "required",
            data_arrivo: "required",
            data_partenza: "required"
        },
        messages: {
            nome: "",
            cognome: "",
            email: "",
            privacy: "Please accept our policy",
            data_arrivo: "",
            data_partenza: ""
        }
    });

    //modulo loading form crea proposta
    $("#form_richiesta").on("submit",function(){
        if ($(this).valid()){
            $("#view_send_form_loading").html('<div class="clearfix">&nbsp;</div><div class="row"><div class="col-md-12 text-center"><img src="Ellipsis-1s-200px.svg" alt="Salvataggio in corso"></div></div><div class="row"><div class="col-md-12 text-center"><small>Salvataggio in corso..., attendere il suo termine!</small></div></div><div class="clearfix"  style="height:10px">&nbsp;</div>');
            $("#pulsante-invio").hide();
        }
    })

    $("#plus_date").on('click',function() {
        var attr = $("#date_alternative").attr('style');
        if(attr == 'display:none'){
            $("#date_alternative").attr('style','display:block');
            $("#plus_date").html('<i class="fa fa-fw  fa-minus"></i> rimuovi date alternative');
        }
        if(attr == 'display:block'){
            $("#date_alternative").attr('style','display:none');
            $("#plus_date").html('<i class="fa fa-fw  fa-plus"></i> aggiungi date alternative');
        }
    });


    $("#link_privacy").on('click',function() {
        $("#box_privacy").toggle();
            <?php if($eqr == 1){?>
                EQR();
            <?}?>    
    });

    $("#marketing").on('click',function() {
            $("#view_profilazione").toggle();
    });

    if ((window.matchMedia('(max-width: 768px)').matches)) {
        $(".righeSogg").hide();
    }
    console.log($("#form-show").width());
    if ($("#form-show").width()<= 610) {
        $(".righeSogg").hide();
    }

    /** controllo se almeno una riga per proposta è stata compliata */
    /** tipo soggiorno */
    if($("select[name*='TipoSoggiorno[]']").val().length > 0){
        $("select[name*='TipoSoggiorno[]']").attr('required',false);
    }else{
        $("select[name*='TipoSoggiorno[]']").attr('required',true);
        $("select[name*='TipoSoggiorno[]']").attr('title',' ');
    }
    $("select[name*='TipoSoggiorno[]']").on("change", function(){
        if($("select[name*='TipoSoggiorno[]']").val().length > 0){
            $("select[name*='TipoSoggiorno[]']").attr('required',false);
        }else{
            $("select[name*='TipoSoggiorno[]']").attr('required',true);
            $("select[name*='TipoSoggiorno[]']").attr('title',' ');
        }
    })
    /** numero camera */
    if($("select[name*='NumeroCamere[]']").val().length > 0){
        $("select[name*='NumeroCamere[]']").attr('required',false);
    }else{
        $("select[name*='NumeroCamere[]']").attr('required',true);
        $("select[name*='NumeroCamere[]']").attr('title',' ');
    }
    $("select[name*='NumeroCamere[]']").on("change", function(){
        if($("select[name*='NumeroCamere[]']").val().length > 0){
            $("select[name*='NumeroCamere[]']").attr('required',false);
        }else{
            $("select[name*='NumeroCamere[]']").attr('required',true);
            $("select[name*='NumeroCamere[]']").attr('title',' ');
        }
    })
    /**  camera */
    if($("select[name*='TipoCamere[]']").val().length > 0){
        $("select[name*='TipoCamere[]']").attr('required',false);
    }else{
        $("select[name*='TipoCamere[]']").attr('required',true);
        $("select[name*='TipoCamere[]']").attr('title',' ');
    }
    $("select[name*='TipoCamere[]']").on("change", function(){
        if($("select[name*='TipoCamere[]']").val().length > 0){
            $("select[name*='TipoCamere[]']").attr('required',false);
        }else{
            $("select[name*='TipoCamere[]']").attr('required',true);
            $("select[name*='TipoCamere[]']").attr('title',' ');
        }
    })
    /**  camera */
    if($("select[name*='NumAdulti[]']").val().length > 0){
        $("select[name*='NumAdulti[]']").attr('required',false);
    }else{
        $("select[name*='NumAdulti[]']").attr('required',true);
        $("select[name*='NumAdulti[]']").attr('title',' ');
    }
    $("select[name*='NumAdulti[]']").on("change", function(){
        if($("select[name*='NumAdulti[]']").val().length > 0){
            $("select[name*='NumAdulti[]']").attr('required',false);
        }else{
            $("select[name*='NumAdulti[]']").attr('required',true);
            $("select[name*='NumAdulti[]']").attr('title',' ');
        }
    })
    /**  adulti */
    if($("select[name*='NumAdulti[]']").val().length > 0){
        $("select[name*='NumAdulti[]']").attr('required',false);
    }else{
        $("select[name*='NumAdulti[]']").attr('required',true);
        $("select[name*='NumAdulti[]']").attr('title',' ');
    }
    $("select[name*='NumAdulti[]']").on("change", function(){
        if($("select[name*='NumAdulti[]']").val().length > 0){
            $("select[name*='NumAdulti[]']").attr('required',false);
        }else{
            $("select[name*='NumAdulti[]']").attr('required',true);
            $("select[name*='NumAdulti[]']").attr('title',' ');
        }
    })

});

    function equalizza_change_bambini(){
            EQR();
    }
                    
    /* calcola_totale_adulti */
    function calcola_totale_adulti() {
        var totale='';
        $("select[name*='NumAdulti[]']").each( function() {
            value = new Number($(this).val());
            totale = new Number(totale + value);
            $('#adulti<?=$idsito?>').val(totale);
        });
    }

    /* calcola_totale_bimbi */
    function calcola_totale_bambini() {
        var totaleb='';
        $("select[name*='NumBambini[]']").each( function() {
            valueb = new Number($(this).val());
            totaleb = new Number(totaleb + valueb);
            $('#bambini<?=$idsito?>').val(totaleb);
        });
    }
    function checkDimension(){
        if ((window.matchMedia('(max-width: 768px)').matches)) {
                $(".righeSogg").hide();
        }
        if ($("#form-show").width()<= 610) {
            $(".righeSogg").hide();
        }
    }
    function eta_bimbi(id){
        /* ON CLICK in base al nunmero dei bambini selezionati si rendono visibili i campi per età */
        $(".NumeroBambini_"+id+"").each(function(){
            if($(".NumeroBambini_"+id+"").val() != ''){
                $(".EtaBambini"+id+"").css("display","block");
            }else{
                $(".EtaBambini"+id+"").css("display","none");
            }
        });
    }

    (function (w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({
            'gtm.start': new Date().getTime(),
            event: 'gtm.js'
        });
        var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s),
            dl = l != 'dataLayer' ? '&l=' + l : '';
        j.async = true;
        j.src =
            'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
        f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', '<?=$TagManager?>');
        
</script>